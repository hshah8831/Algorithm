Assuming that the input is static and not updating online.
Assuming the input fits into the memory.

The code uses TreeMap to store the elements and their frequency in the input.
Makes a ideal capacity bin array which is used to compare the input element frequency and 
the ideal bucket capacity, and finally assings the element/s in an appropriate bucket